//
//  main.m
//  ChangeProjectFilePreName
//
//  Created by qingzhao on 2020/3/2.
//  Copyright © 2020 qingzhao. All rights reserved.
//

#import <Foundation/Foundation.h>

#define OriginalPre @"Heqz_" // 原来的前缀名
#define TargetPre @"TargetPre" // 想要替换成的前缀名

void renameClassName(NSString* dir, NSString* fileName, NSFileManager* fileMgr){
    NSString* clsName = fileName;
    if([clsName hasPrefix:OriginalPre]){
        clsName = [clsName stringByReplacingOccurrencesOfString:OriginalPre withString:TargetPre];
    }
    NSString* targetFileName = [dir stringByAppendingPathComponent:clsName];
    [fileMgr moveItemAtPath:[dir stringByAppendingPathComponent:fileName] toPath:targetFileName error:nil];
    
//    if([fileName hasPrefix:OriginalPre]){
//        [fileMgr removeItemAtPath:[dir stringByAppendingPathComponent:fileName] error:nil];
//    }
}

void changePreNameWithDir(NSString* dir, NSFileManager* fileMgr){
    NSArray* array = [fileMgr contentsOfDirectoryAtPath:dir error:nil];
    BOOL isDir = NO;
    for(NSString* item in array){
        if([item hasSuffix:@".h"] || [item hasSuffix:@".m"]){
            renameClassName(dir, item, fileMgr);
        }else{
            NSString* tempDir = [dir stringByAppendingPathComponent:item];
            [fileMgr fileExistsAtPath:tempDir isDirectory:&isDir];
            if(isDir){
                changePreNameWithDir(tempDir, fileMgr);
            }
        }
    }
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        
        NSString* rootDir = @"rootDir"; // 工程文件所在的目录
        NSFileManager* fileMgr = [NSFileManager defaultManager];
        changePreNameWithDir(rootDir, fileMgr);
    }
    return 0;
}
